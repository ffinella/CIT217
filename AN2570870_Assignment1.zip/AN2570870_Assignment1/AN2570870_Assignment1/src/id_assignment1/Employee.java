/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id_assignment1;

/**
 *
 * @author finel
 */
import java.util.Date;
public class Employee extends Person {

    private String office;
    private Double salary;
    private Date dateHired;
    
    public Employee(String name) {
        super(name);
        dateHired = new Date();
       
    }
    
    public String toString(){
        return "Employee: ";
    }
}
