/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id_assignment1;

/**
 *
 * @author finel
 */
public class Person {
    
    private String name;
    private String address;
    private String phonenumber;
    private String emailAddress;
    
    public Person(String name) {
        this.name = name;
    }
    public String toString() {
        return "Person name: " + name;
    }
 }
