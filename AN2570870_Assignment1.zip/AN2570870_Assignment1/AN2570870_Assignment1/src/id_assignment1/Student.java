/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id_assignment1;

/**
 *
 * @author finel
 */
public class Student extends Person {
    
     public static final String FRESHMAN = "Freshman";
    public static final String SOPHOMORE = "Sophomore";
    public static final String JUNIOR = "Junior";
    public static final String SENIOR = "Senior";

    private String status;

    public Student(String name, String status) {
        super(name);
        this.status = status;
    }
    
    public String toString() {
        return "Student status: " + status;
    }
    
    
}
