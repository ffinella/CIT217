/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id_assignment1;

/**
 *
 * @author finel
 */
public class Staff extends Employee {
    
    private String title;
    
    public Staff(String name) {
        super(name);
    }
    public String toString() {
        return "Staff: ";
    }
}
