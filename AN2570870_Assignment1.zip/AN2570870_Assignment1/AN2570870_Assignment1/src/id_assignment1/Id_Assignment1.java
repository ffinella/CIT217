/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package id_assignment1;

/**
 *
 * @author finella
 */
public class Id_Assignment1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        Stock stock = new Stock("ORCL", "Oracle Corporation");

                stock.setPreviousClosingPrice(34.5);
                stock.setCurrentPrice(34.35);

                System.out.println(stock);
                System.out.println("Percent Change: " + stock.getChangePercent() + "%");
    
//Number 2
        Person p = new Person("John");
        Student s = new Student("Alice", Student.FRESHMAN);
        Employee e = new Employee("Mark");
        Faculty f = new Faculty("Dr. Smith");
        Staff st = new Staff("Mary");

        System.out.println(p);
        System.out.println(s);
        System.out.println(e);
        System.out.println(f);
        System.out.println(st);
    } 
    
}
