/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id_assignment1;

/**
 *
 * @author finel
 */
public class Stock {
    
    private String symbol;
    private String name;
    private Double previousClosingPrice;
    private Double currentPrice;
    
    public Stock(String symbol, String name){
        this.symbol = symbol;
        this.name = name;
        
    }
    
    public Stock(Stock other) {
        this.symbol = other.symbol;
        this.name = other.name;
        this.previousClosingPrice = other.previousClosingPrice;
        this.currentPrice = other.currentPrice;
    }
    
    public double getChangePercent (){
        Double change = currentPrice - previousClosingPrice;
        Double percent = (change / previousClosingPrice) * 100;
        return percent;
    }
    
    public String toString() {
        return "Stock: " + symbol + "," + name +
               ", Previous: " + previousClosingPrice +
               ", Current " + currentPrice;
    }
    
    //these are setters to change price
    public void setPreviousClosingPrice(Double price) {
        previousClosingPrice = price;
    }
    
    public void setCurrentPrice(Double price) {
        currentPrice = price;
    }
}
