/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package an2570870_assignment3;

/**
 *
 * @author finel
 */
import java.util.ArrayList;
import java.util.Scanner;
public class Library {
    
    private ArrayList<Item> items = new ArrayList<>();
    private ArrayList<Borrower> borrowers = new ArrayList<>();
    
    public void adItem(Item item) {
        items.add(item);
    }
    
    public void addUser(Borrower user) {
        borrowers.add(user);
    }
    
    public Item searchItem(String title) {
        for (Item i : items) {
            if (i.getTitle().equalsIgnoreCase(title)) {
                return i;
            }
        }
        return null;
    }
    
    public Borrower searchBorrowers(String name) {
        for (Borrower b : borrowers) {
            if (b.getName().equalsIgnoreCase(name)) {
                return b;
            }
        }
        return null;
    }
    
    public static void main(String[] args) {
        
        Library lib = new Library();
        Scanner input = new Scanner(System.in);
        int choice;
    
    do {
        System.out.println("Menu");
        System.out.println("1. Add User");
        System.out.println("2. Add Book");
        System.out.println("3. Borrow Book");
        System.out.println("4. Return Book");
        System.out.println("5. Search Book");
        System.out.println("6. Search Borrower");
        System.out.println("7. Quit");
        
        choice = input.nextInt();
        input.nextLine();
        
        if (choice == 1) {
            System.out.print("Enter name: ");
            String name = input.nextLine();
            lib.addUser(new Borrower(1, name));    
        }
        
        else if (choice == 2){
            System.out.print("Enter title: ");
            String title = input.nextLine();
            lib.addItem(new Book(1, title, "Unknown", "Unknown"));     
        }
        
        else if (choice == 5) {
            System.out.print("Enter book name: ");
            String name = input.nextLine();
            Item item = lib.searchItem(name);
            if (item != null) item.displayInfo();
        }
        
        else if (choice == 6) {
            System.out.print("Enter borrower name: ");
            String name = input.nextLine();
            Borrower b = lib.searchBorrower(name);
            if (b != null) b.displayInfo();
        }
        
    }while (choice !=7);
    
        
    }
}
