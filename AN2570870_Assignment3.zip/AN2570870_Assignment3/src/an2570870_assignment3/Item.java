/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package an2570870_assignment3;

/**
 *
 * @author finel
 */
public abstract class Item {
    
    protected int id;
    protected String title;
    
    public Item(int id, String title) {
        this.id = id;
        this.title = title;   
    }
    
    public abstract void displayInfo();
    
    public String getTitle() {
        return title;
    }
    
    
}
