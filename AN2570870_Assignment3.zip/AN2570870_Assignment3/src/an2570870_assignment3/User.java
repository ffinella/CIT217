/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package an2570870_assignment3;

/**
 *
 * @author finel
 */
public abstract class User {
    
    protected int id;
    protected String name;
    protected String studentId;
    
    public User(int id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public User(String name,String studentId) {
        this.name = name;
        this.studentId = studentId;    
    }
    
    public abstract void displayInfo();
    
    public String getName() {
        return name;
    }
}
