/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package an2570870_assignment3;

/**
 *
 * @author finel
 */
import java.util.ArrayList;

public class Borrower extends User {
    
    private ArrayList<Item> borrowedItems;
    
    public Borrower(int id, String name) {
        super(id, name);
        borrowedItems = new ArrayList<>();
    }
    
    public void borrowItem(Item item) {
       borrowedItems.add(item);
       System.out.println("Item borrowed.");
    }
    
    public void returnItem(Item item) {
        borrowedItems.remove(item);
        System.out.println("Items returned. ");  
    }
    
    public void displayBorrowedItems() {
        for (Item item : borrowedItems) {
            item.displayInfo();
        }
    }
}
