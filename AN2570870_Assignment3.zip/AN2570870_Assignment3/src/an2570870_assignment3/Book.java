/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package an2570870_assignment3;

/**
 *
 * @author finel
 */
public class Book extends Item {
    
    private String author;
    private String genre;
    
    public Book(int id, String title, String genre) {
        super(id,title);
        this.author = author;
        this.genre = genre;
    }
    
    public void displayInfo() {
        System.out.println("Book: " + title + ",Author: " + author + ", Genre" + genre);   
    }
}
