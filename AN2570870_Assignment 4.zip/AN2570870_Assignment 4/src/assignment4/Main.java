/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment4;
import java.util.Scanner;
/**
 *
 * @author finel
 */ 

public class Main {
    public static void main(String[] args) {
        Inventory inv = new Inventory();
        Scanner sc = new Scanner(System.in);
        
        int choice = -1;
        
        while (choice != 0){
            System.out.println("Menu");
            System.out.println(" 1 add");
            System.out.println(" 2 display");
            System.out.println(" 3 search");
            System.out.println(" 4 update quantity");
            System.out.println(" 5 delete");
            System.out.println(" 6 total value");
            System.out.println(" 0 exit");
            
            System.out.println("choice: ");
            choice = sc.nextInt();
            
            if (choice == 1) {
                System.out.print("id: ");
                int id = sc.nextInt();
                sc.nextLine();
                
                System.out.print("name: ");
                String name = sc.nextLine();

                System.out.print("qty: ");
                int q = sc.nextInt();

                System.out.print("price: ");
                float p = sc.nextFloat();

                inv.addProduct(id, name, q, p);
            }

            else if (choice == 2) {
                inv.displayInventory();
            }
            
            else if (choice == 3) {
                System.out.print("enter id: ");
                int id = sc.nextInt();
                inv.searchProduct(id);
            }

            else if (choice == 4) {
                System.out.print("id: ");
                int id = sc.nextInt();

                System.out.print("new qty: ");
                int q = sc.nextInt();

                inv.updateQuantity(id, q);
            }

            else if (choice == 5) {
                System.out.print("id: ");
                int id = sc.nextInt();
                inv.deleteProduct(id);
            }

            else if (choice == 6) {
                inv.totalValue();
            }
            
            else if (choice == 0) {
                System.out.println("bye");
            }

            else {
                System.out.println("wrong choice");
            }
        }
    }
}
