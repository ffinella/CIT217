/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment4;

/**
 *
 * @author finel
 */
public class Inventory {
    Product head;
    
    public void addProduct(int id, String name, int quantity, float price) {
        Product newProduct = new Product(id, name, quantity, price);
        
        if (head == null){
            head = p;
        } else {
            Product temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = p;
        }
        
        System.out.println("product added");
    }
    
    //display 
    public void displayInventory() {
        if (head == null) {
            System.out.println("nothing in inventory");
            return;
    
        }
        
        Product temp = head;
        
        while (temp != null) {
            System.out.println("ID: " + temp.id);
            System.out.println("Name: " + temp.name);
            System.out.println("Quantity: " + temp.quantity);
            System.out.println("Price: " + temp.price);
            
            temp = temp.next;
        }   
    }
    
    // search
    public void searchProduct(int id){
        Product temp = head;
        
        while (temp != null) {
            if (temp.id == id){
                System.out.println("found product");
                System.out.println(temp.name + " " + temp.quantity + " " + temp.price);
                return;
            }
            temp = temp.next;
    }
        
    System.out.println("not found");
       
}
    // update
    public void updateQuantity(int id, int quantity) {
        Product temp = head;
        
        while (temp != null) {
            if (temp.id == id) {
                temp.quantity = quantity;
                System.out.println("quantity changed");
                return;
            }
            temp = temp.next;
            
        }
        
        System.out.println ("id not found");
        
    }
    
    // delete
    public void deleteProduct(int id){
        if (head == null) {
            System.out.println("empty list");
            return;
        }
        
        if (head.id == id) {
            head = head.next;
            System.out.println("deleted");
            return;
        }
        
        Product temp = head;
        
        while (temp.next != null) {
            if (temp.next.id == id) {
                temp.next = temp.next.next;
                System.out.println("deleted");
                return;
            }
            temp = temp.next;
        }
        
        System.out.println("id not found");
    
    }

    // total value
    public void totalValue() {
        float total = 0;
        Product temp = head;
        
        while (temp != null) {
            total = total + (temp.quantity * temp.price);
            temp = temp.next;
        }

        System.out.println("total value is" + total);
    }
}


