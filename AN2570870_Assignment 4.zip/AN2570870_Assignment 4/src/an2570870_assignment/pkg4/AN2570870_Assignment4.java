/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package an2570870_assignment.pkg4;

/**
 *
 * @author finel
 */
public class AN2570870_Assignment4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
